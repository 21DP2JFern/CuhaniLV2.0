<template>
    <Header />
</template>

<script>
import Header from '../components/Header.vue'

export default{
    name: "News",
    components:{
        Header
    }
}
</script>