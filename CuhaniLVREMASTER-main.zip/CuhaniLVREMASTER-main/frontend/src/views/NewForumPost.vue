<template>
</template>
  
  <script>
/*   import Header from '../components/Header.vue';
  import Line from '../components/Line.vue';
  import axios from 'axios';
  
  export default {
    name: "ForumHubView",
    components: {
      Header,
      Line
    },
    data() {
      return {
        forumPosts: []
      };
    },
    mounted() {
    },
    methods: {
      getForumPosts() {
        axios
          .get('127.0.0.1:8000/getForumPost/?id=2') 
          .then(response => {
            this.forumPosts = response.data.data;
          })
          .catch(error => {
            console.error('Error fetching forum posts:', error);
          });
      }
    }
  }; */
  </script>
  
  <style>
  </style>