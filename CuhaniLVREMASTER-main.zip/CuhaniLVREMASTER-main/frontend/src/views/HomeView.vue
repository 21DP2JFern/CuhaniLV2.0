<template>
<Header />
</template>

<style>

</style>

<script>
import Header from '../components/Header.vue'

export default{
    name: "Home",
    components:{
        Header
    }
}
</script>
