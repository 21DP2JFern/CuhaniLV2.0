<template>
  <RouterView/>
</template>
<script>
import { RouterLink, RouterView } from 'vue-router'

import axios from 'axios';

</script>
<style scoped>
</style>
